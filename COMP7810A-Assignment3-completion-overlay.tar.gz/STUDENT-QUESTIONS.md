# COMP 7810A Assignment Three — Discussion Questions

The following answers distinguish executable on-chain invariants from off-chain legal and financial promises. Figures use the lab's 6-decimal USDC, 18-decimal shares and 8-decimal NAV conventions.

## A. Custody — where the asset actually is (plank a)

### A1. What replaces the stablecoin backing invariant?

A plausible economic solvency statement is that the independently verified market value of custodied Treasury bills, plus unencumbered cash at the vault and redemption queue, should cover the value of outstanding tBILL shares plus cash already owed on settled tickets. Expressed in USDC units, it resembles `verifiedTreasuryValue + availableReserveCash + queueCash >= totalClaimValue() + totalClaimable()`. The settlement component matters because once a request is settled its shares are burned, but the beneficiary still has a legal claim on cash until `claim()` succeeds. One must also avoid double-counting assets, pending tickets or custodial cash.

This is not an executable proof in the present lab. `MockTBillCustodian.realHoldings()` is a mutable six-decimal integer, not an independently established inventory of identified securities. `recordPurchase()` can increase it without transferring any USDC. `vault.totalClaimValue()` depends on the single reporter-controlled NAV, not a price discovery mechanism. Even if an equality between those two reported numbers happens to hold, both may be incorrect simultaneously. Ex2 proves the narrower statements: shares can exist with zero recorded holdings, and recorded holdings can rise without cash moving.

A production version would reconcile custody statements, settlement accounts, prices, accrued interest and liabilities, impose conservative haircuts, and publish timestamped third-party attestations. It would still depend on banks, auditors and enforceable legal ownership. The contract can enforce a relation between inputs; it cannot prove that the off-chain inputs describe actual assets.

### A2. Why is the SPV a technical requirement, and what happens in custodian insolvency?

An on-chain balance is neither a Treasury security nor a court-enforceable ownership title. Tokenholders need a legal counterparty against which their rights can be asserted, especially if the sponsor, investment manager or custody bank fails. An SPV can hold the securities separately from the issuer's operating assets and define beneficial interests, servicing duties and redemption priority. Bankruptcy remoteness reduces the chance that the issuer's general creditors can claim the portfolio. It does not mean risk disappears, and it requires documentation and implementation rather than merely naming a contract “custodian”.

If the custodian goes bankrupt, the outcome depends on whether the T-Bills are legally segregated client property, how they are registered, whether there are liens, and which insolvency and securities laws apply. A properly segregated position may ultimately be returned or transferred to a replacement custodian, but access can be delayed while administrators reconcile records. If assets are commingled, pledged or missing, tokenholders may instead face a shortfall and become creditors of the relevant entity. Nothing in `TBillToken.balanceOf()` guarantees a direct claim against the US Treasury.

The architecture must therefore specify the SPV's ownership of securities, custodian segregation and reconciliations, tokenholder rights, insolvency procedures and a legally recognized transfer register. `MockTBillCustodian` intentionally models none of that; its `realHoldings()` result is testimony, not property. This is why legal enforceability forms part of the bridge rather than being a footnote to Solidity.

## B. Attestation — how the chain learns the truth (plank b)

### B1. Single reporter failure modes and mitigations

`REPORTER_ROLE` makes `attest()` an authorization check, not a truth check. First, a stolen or bribed reporter key can publish an invented NAV; `vault.subscribe()` and the redemption queue will price the entire book from that number. Ex7 demonstrates why this can drain reserves while the bookkeeping tests remain green. The mitigation is not simply a stronger password: use a multisignature or quorum of independently appointed NAV providers, with role separation, key rotation and a monitored emergency revocation process.

Second, an honest operator can enter the wrong decimals, sign the wrong valuation date or transpose digits. Mitigations include a feed schema with explicit decimals and as-of time, reasonable deviation bounds, secondary source comparisons and a review process before publication. Third, even a correctly calculated price becomes stale when the reporter, network or data vendor fails. A consumer should reject a zero or future `updatedAt`, an incomplete round and values older than its maximum permitted age. The optional `NavSafetyReader` prototype shows this type of validation, without pretending it authenticates the custodian's holdings.

Fourth, an apparently accurate NAV can reflect misstated custody, bad accrual accounting or deliberately omitted liabilities. Independent custodian reconciliation, periodic external assurance, incident reporting and contractual liability are needed. Timelocks alone are not enough because users may redeem before a delayed correction. A sensible control stack combines prevention, bounded exposure, rapid suspension of new subscriptions, and a transparent mechanism for correcting erroneous prices without silently rewriting paid tickets.

### B2. Exploiting a stale-but-honest NAV

A stale NAV is not necessarily a lie. Suppose yesterday's valid NAV was $1.00 per share, but a Treasury market repricing or a fund-specific loss makes today's fair value $0.95. If the on-chain feed remains frozen at $1.00, an informed investor can offer shares for redemption at the stale, overly generous amount and shift the loss to holders who remain. Conversely, if the fair NAV has risen to $1.05, the same investor can subscribe at $1.00 and obtain too many shares, diluting existing investors. This is adverse selection: the informed trader acts only when the outdated price is favorable to them.

In this lab `MockPriceFeed.latestRoundData()` reports the current block timestamp, so its original implementation cannot honestly model an aged observation. The reader also has to check that the round is complete and the timestamp actually describes when the valuation was produced, not when an old answer was republished. A short freshness threshold prevents known stale values from being used, but overnight markets and T-Bill fund valuation procedures may require a calendar-aware policy rather than a simplistic fixed number of seconds.

An economically stronger design uses a valuation cut-off: subscriptions and redemptions are queued for the next published, independently reconciled NAV rather than executed against a known stale price. Circuit breakers, divergence limits and observable reporting timestamps help detect attacks. No heartbeat rule on its own proves that a fresh price represents real, correctly custodied securities.

## C. Redemption — T+1 does not settle on-chain (plank c)

### C1. Who benefits when the NAV rises after enqueue?

The queue computes `assetsLocked` at `enqueue()` and never changes it. Suppose Alice enqueues 100 shares at a $1.00 NAV; her claim is fixed at $100. If the genuine NAV rises to $1.10 before the SPV sells securities and settlement occurs, Alice still receives $100. The remaining fund effectively retains the extra $10 of economic value, so remaining shareholders benefit relative to a scheme in which Alice participated in the appreciation through the settlement cut-off. If NAV falls instead, locking the higher old value protects Alice and shifts the loss toward the investors who remain. Neither outcome is an accidental arithmetic error; it is an allocation of market risk built into the chosen cut-off.

A fixed enqueue price can be reasonable if the fund's prospectus clearly defines an irrevocable trade date, knows how to calculate that day's independently struck NAV, and maintains liquidity against the commitment. But for a fund where the same reporter can change the NAV by fiat, it enables an insider to lock a fabricated payout. I would prefer requests that freeze the number of shares at submission, then determine cash due from a verified NAV struck at a published cut-off, with investor disclosure of valuation timing and exceptional-market rules.

The cash buffer is a separate issue. `vault.reserveBalance() >= queue.pendingAssets()` is not a valid invariant: reserves can be invested in Treasuries and may be unavailable until T+1, even if the off-chain portfolio is solvent. The two executable invariants instead protect escrowed shares and cash already credited to claimants.

### C2. Freezing redemption and redesigning the pause lever

After the Reserve Primary Fund broke the buck in 2008, redemption restrictions and delayed payments illustrated how investors can lose immediate access even when a portfolio still has residual value. During USDC's March 2023 depeg, market holders could not necessarily convert instantly at all times because bank rails and operating windows mattered, but the issuer did not impose the same general, multi-day redemption shutdown. Restoring confidence and a credible conversion path can support the price; closing that path may amplify a discount and create a queue of users desperate to exit.

For a tokenized T-Bill fund, closing redemption should be an explicit policy decision about accepting new tickets, valuing existing tickets, settling matured tickets and releasing already-settled claims. Those are distinct functions. `pause()` in the lab is implemented in `TBillToken._update`, so it blocks transfers, minting and burning together. A queue settlement burns escrowed shares and therefore reverts while globally paused. That blunt mechanism can make a temporary shortage worse by preventing even fully funded claims from completing.

I would use separate emergency modes: stop new subscriptions and ordinary transfers while allowing the queue to settle and pay funded claims; optionally stop new enqueue requests if there is a legal dealing suspension; and reserve a last-resort full halt for fraud or asset-seizure scenarios. Powers should be segregated across a fast incident-response multisig and slower governance, with public events, finite review intervals, priority rules and clear treatment of existing tickets. Liquidity controls cannot manufacture missing cash, but they can avoid trapping solvent claimants unnecessarily.

## D. Admission — the guest list and the backdoor (plank d)

### D1. Where should the whitelist boundary be?

A regulated Treasury fund has legitimate investor-eligibility and transfer restrictions that a permissionless ERC-20 lacks. A financial institution may need to know the beneficial owner, jurisdiction, sanctions status and investor category before issuing a security or recognizing a transfer. The lab's `TBillToken._update` implements a simple, auditable version: minting checks the recipient, a transfer checks both endpoints, and burning checks the holder. Ex4 confirms that an unapproved investor cannot subscribe into shares or receive them from an approved holder.

However, “not yet KYC'd” is not the same as “sanctioned”, and a single boolean erases that distinction. A production registry should record verified claims from accredited identity providers, their expiry dates and permitted jurisdictions without putting unnecessary personal information on a public chain. A compliance agent should be able to suspend an address after a documented trigger, with an appeal and remediation process. Routine KYC updates should not silently give the operator discretion to confiscate all holdings.

I would keep tokenholder eligibility separate from transaction authorization: the issuer and transfer agent administer enrollment under a governed policy, while an independently authorized incident team manages emergency freezes. An audit log should identify who changed an account's status and which approved case justified it. A token cannot decide whether its owners have a valid legal entitlement; it can only enforce a registry whose off-chain procedures and accountability are trustworthy. The optional simplified permission module illustrates the separation, not a complete ERC-3643 compliance stack.

### D2. Freezing versus issuer confiscation — both sides and safeguards

Freezing transfers is defensible when an address is sanctioned, a private key is stolen or a court order prevents disposal of disputed assets. Issuers of regulated securities may also need mandatory transfers or cancellations to comply with litigation, recover a lost-key investor's shares, or correct operational mistakes. Without any extraordinary administrative path, illegal or irrecoverable positions could remain stuck indefinitely. Conversely, issuer-controlled freeze and burn powers create material censorship and property-rights risks. A mistaken blacklist can halt an innocent holder; compromised role keys could be used to freeze or destroy positions at scale.

Ex4.3 captures a subtle design contradiction. `TBillToken.burn(from, amount)` is guarded by `MINTER_ROLE`, yet the ERC-20 `_update(from, address(0), amount)` path also requires `from` to be whitelisted. Once an address is removed from the list, even a privileged burn reverts. If forced recovery is intended, the design needs a narrowly defined exception rather than weakening all whitelist checks.

I would separate routine issuance, KYC administration, emergency freeze and legally authorized forced recovery into distinct roles. Recovery would require a recorded case identifier, approval by a multi-party committee or court-backed process, a destination that remains KYC eligible and transparent events; emergency freeze could be fast but time-limited. Administrative changes should be monitored and subject to independent review and key rotation. In a fund whose token represents a legal claim, the power to correct the register must exist alongside procedural safeguards protecting legitimate owners.

## E. Tests — Ex2, Ex3 and Ex4

| Plank | Required scenario | Implemented test function |
|---|---|---|
| a | Shares exist while custodian holds nothing | `test_Ex2_SharesExistWhileTheCustodianHoldsNothing` |
| a | `realHoldings()` changes without cash moving | `test_Ex2_RealHoldingsIsJustANumber` |
| b | Claim value floats, share count is unchanged | `test_Ex3_TheClaimFloats_TheShareCountDoesNot` |
| b | One attestation reprices the whole book | `test_Ex3_OneCallMovesTheWholeBook` |
| d | No KYC means no shares | `test_Ex4_NoKyc_NoShares_EvenIfYouPay` |
| d | Sender is listed but receiver is not | `test_Ex4_TransferChecksBothEndpoints` |
| d | Delisting prevents transfer and issuer burn | `test_Ex4_FreezeBeatsConfiscation` |

**Most likely attack: compromised or stale attestation (plank b), compounded by redemption liquidity (plank c).** A reporter key is a concentrated privilege, and both subscriptions and fixed-price enqueue tickets depend on its value. An attacker who can temporarily change NAV can subscribe under a low value and redeem under a high one, locking an inflated cash liability ahead of honest holders. The optional `test_falseNav` demonstrates this using the pre-authorized reporter role: it spends real mock USDC, creates shares, posts an arbitrary NAV, enqueues at the false valuation, then takes cash from the vault through normal settlement and claim functions. Neither a correct whitelist nor the two mechanical queue invariants detects the lie. Independent custody reconciliation, separate signing authorities, bounds on NAV changes, verified timestamps and a limit on redemption cash outflows would reduce the exposure. Off-chain legal, reporting and operational controls are necessary because a smart contract cannot prove that the claimed Treasuries exist.
