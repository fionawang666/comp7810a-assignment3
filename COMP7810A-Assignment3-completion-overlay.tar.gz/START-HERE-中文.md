# COMP7810A Assignment 3：从老师原仓库到 Moodle 的完整流程

> 本 ZIP / TAR.GZ 是**修改叠加包**，不是完整原项目；它必须覆盖到官方
> `https://github.com/hgwoops/rwa-lab-2026` 的完整源码根目录，保留老师的 `lib/`。
> 不要把本叠加包本身当作 Moodle 最终作业 ZIP！
> 本包由课程 PDF、Lab PPT 和老师 GitHub 源码编写，但当前生成环境没有 Foundry，
> **绝不声称代码已经执行通过**。你的 Codespace 运行结果才是唯一的真实证据。

## 0. 评分要求先看清

- **40%**：Ex0–Ex6。`make doctor`、`make test`、`make exercise` 全绿。
- **20%**：用临时 Sepolia 钱包部署 **七份合约**，七个地址及 Etherscan 验证链接放到 README 的 `## Deployment (Sepolia)`。
- **25%**：`STUDENT-QUESTIONS.md` 八道 A1–D2 每题 150–300 英文词，另有 E 表格及额外攻击场景。
- **15%**：源码可读性和能看到四板桥、USDC 现金与 tBILL 份额流向的架构图。
- Tier 3 是 **不计分的扩展**：Ex7、staleness、ERC-3643 类权限、真实 Chainlink 类 feed。
- **PDF 写的 Assignment 3 截止是 2026-10-16 23:55**。你之前说的 10/20 延期是 Assignment 2；请向 Moodle 核实是否也覆盖 Assignment 3。
- ZIP 要保留 `lib/`；绝不能含真实私钥。老师的公开 Anvil 示例私钥也在合并脚本中移除，免得被严格的关键字检查误伤。

## 1. 建立你自己的 Private GitHub 仓库

1. 登录 GitHub → https://github.com/new 。
2. Repository name 填 `comp7810a-assignment3`；选 **Private**；勾选 README 建立仓库。
3. 上传 `COMP7810A-Assignment3-completion-overlay.tar.gz` 到仓库根目录（上传就是为了 Codespaces 读到它）。
4. 仓库 `Code` → `Codespaces` → `Create codespace on main`。
5. 打开菜单 Terminal → New Terminal，下面所有命令均在项目根目录执行。

## 2. 在新的 Codespace 安装老师原项目，并叠加已写代码

```bash
pwd
# 从老师仓库取得包含完整 lib/ 的原始文件
git clone https://github.com/hgwoops/rwa-lab-2026.git /tmp/rwa-lab-2026-original
# 只复制项目内容，不复制老师的 .git
(cd /tmp/rwa-lab-2026-original && tar --exclude='.git' -cf - .) | tar -xf -
# 解开本包，覆盖老师的 TODO 文件并增加答案、可选扩展、图和脚本
tar -xzf COMP7810A-Assignment3-completion-overlay.tar.gz
python3 --version
# 若 Python 不存在：apt-get update && apt-get install -y python3
python3 scripts/finish-readme.py
python3 scripts/harden-demo-keys.py
rm -f COMP7810A-Assignment3-completion-overlay.tar.gz
ls -lah
ls lib/forge-std lib/openzeppelin-contracts
python3 scripts/preflight-project.py
```

然后 `git status --short` 检查发生的变更。不要盲目 `git add -A` 前提交包含 `.env` 的工作目录。

## 3. 安装并测试 Foundry

Codespaces 命令面板（Mac `Shift+Cmd+P`） → `Codespaces: Rebuild Container`。本叠加包会为原容器补充 Python 3、zip 和 unzip，重建后这些工具也会保留。完成后：

```bash
forge --version
cast --version
anvil --version
make doctor
make test
make exercise
make challenge
forge test --match-path 'test/tier3/*.t.sol' -vv
forge test
```

全部通过后执行：

```bash
python3 scripts/capture-checks.py
```

真实终端结果会写到 `docs/submission-checks.txt`。任何一个检查失败，脚本都会返回非零，必须处理，而不是先声明通过。

### 自己做 Ex1（暖身，非评分）

打开两个终端：第一个 `make anvil`，第二个 `export ANVIL_KEY=...`（从当前 Anvil 控制台复制第一个**公开本地演示账户**的测试私钥；只写在 shell，不写 README 或 Git 文件），再 `make deploy-anvil`。复制打印的七个本地地址，按老师 `EXERCISES.md` 的 Ex1 执行 faucet、subscribe、nav、redeem。这里使用的是本地 Anvil，**不等于 Sepolia 部署**。

## 4. Tier 2：Sepolia 部署 + 源码验证（正式评分 20%）

1. 新建**专用、可丢弃的钱包**，绝不能使用主钱包；少量 Sepolia 测试 ETH 足以测试，但实际用量受网络 gas 影响。
2. 在 Codespace 项目根目录新建本地 `.env`，填写三项：
   ```text
   PRIVATE_KEY=0x...only-in-local-env...
   SEPOLIA_RPC_URL=https://...your-testnet-provider...
   ETHERSCAN_API_KEY=...your-key...
   ```
   `.env` **永远不要上传/提交/截图**。不要在聊天中粘贴私钥。
3. 用 `set -a; source .env; set +a` 让 shell 进程拥有变量；`git status --short` 确保 `.env` 被忽略。
4. 运行：
   ```bash
   forge script script/Deploy.s.sol:Deploy \
     --rpc-url "$SEPOLIA_RPC_URL" --broadcast --verify \
     --etherscan-api-key "$ETHERSCAN_API_KEY" -vvvv
   ```
   `Deploy.s.sol` 使用 `vm.envUint("PRIVATE_KEY")`。如果你的 Foundry 版本要求明确提供链 ID/verify 参数，先运行 `forge script --help`，按当前环境调整，而不是猜测广播成功。
5. 按脚本打印的顺序记录地址（7 个）：`MockUSDC`、`ComplianceRegistry`、`MockPriceFeed`、`TBillToken`、`MockTBillCustodian`、`TBillVault`、`RedemptionQueue`。
6. 逐个打开 `https://sepolia.etherscan.io/address/你的地址#code`，查看 `Contract` → `Code` → `Source Code Verified`。如为 Similar Match，请如实写 Similar，不要冒充 Exact。每个地址保存验证截图放 `docs/etherscan-<contract>.png`。
7. 把这 **七个真实地址和链接**写入 README 的 `## Deployment (Sepolia)` 表格，替换所有 `NOT DEPLOYED YET` 和 `NOT VERIFIED YET`。也可附部署交易哈希。
8. 确认 5 个必须授权的连线：Vault 有 MINTER_ROLE，Queue 有 MINTER_ROLE，Vault 认 Queue，Queue 在白名单，Custodian 允许 Vault。

**重要：** `MockUSDC`、`MockTBillCustodian`、`MockPriceFeed` 只是实验模型，不代表任何真实国债或真实的 Chainlink NAV。为了完成题目也不需要把所有 Tier 3 版本都部署到 Sepolia，正式 PDF 只要七个基础合约。

## 5. 截图与文字论证

- `forge test` 通过：截到完整最后汇总（不是随便截几行 PASS），放 `docs/forge-test-all-green.png`。
- Tier 2：截 7 张 Contract → Code 页面（建议），放 `docs/`。
- README SVG 图已经包括四块桥板、现金/份额两类流动、价格报告和权限控制；在 GitHub README 预览看图是否正常。
- `STUDENT-QUESTIONS.md` 已按每题 150–300 词起草，请自己读一遍并确认理解每个结论。
- 附加 Ex7 + 三个原型可选，`test/tier3/OptionalExtensions.t.sol` 是真实性检查来源；不要在 README 声称有真实合规身份或真实 Treasury NAV Chainlink 现场接入。

## 6. 保存到 GitHub

```bash
git status --short
git add -A -- README.md STUDENT-QUESTIONS.md EXERCISES.md Makefile \
  src test script scripts docs foundry.toml .devcontainer .gitignore .env.example lib
# 注意：git add 出现路径不存在错误时去掉对应路径重试；绝不添加 .env
git diff --cached --name-status
git diff --cached --check
git commit -m "Complete RWA bridge exercises and document deployment"
git push origin main
git status -sb
```

Private 仓库外人看不到，Moodle ZIP 不受影响。如果老师单独要仓库链接，须邀请 TA 使用 GitHub 账户权限。

## 7. 生成 Moodle ZIP（只有所有检查通过、七个真实地址已经填写时才允许）

先执行 `python3 scripts/audit-submission.py`，修正检查报告的项目后再打包。

```bash
python3 scripts/audit-submission.py
python3 scripts/package-submission.py
```

它将生成 `Assignment3-Yijia-Wang-final.zip`，自动排除 `.git`、`.env`、`cache`、`out`、`broadcast`、常见敏感扩展名，以及其他 ZIP。本脚本拒绝对未验证的项目打包。还要**人工检查**是否遗漏任何钱包信息；打包器不是密码扫描器。

在 Codespaces 文件栏右键 `Download` 这个新 ZIP。Moodle 上传这个 ZIP，提交后确认最终状态并截图。先在 Moodle 核实 Assignment 3 的真实延期/迟交政策。

## 8. 安全及准确性

- 不要使用真实金融资产、主网或主钱包；只用本地 Anvil 和 Sepolia。
- 不要把外部随意选取的 Chainlink ETH/USD feed 当成 Treasury NAV。
- 源码通过测试、合约成功部署、Etherscan 完成验证是三个独立目标。一个不代表另外两个。
- 如果 Codespace 报错，把**完整错误日志中不含凭证的部分**发给我，按具体报错修。
