// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {IPriceFeed} from "../../src/exercises/IPriceFeed.sol";
import {NavSafetyReader} from "../../src/tier3/NavSafetyReader.sol";
import {ChainlinkNavAdapter, IAggregatorV3} from "../../src/tier3/ChainlinkNavAdapter.sol";
import {RegulatedTransferPolicy} from "../../src/tier3/RegulatedTransferPolicy.sol";
import {RegulatedTBillToken} from "../../src/tier3/RegulatedTBillToken.sol";
import {GuardedSubscriptionVault} from "../../src/tier3/GuardedSubscriptionVault.sol";
import {MockUSDC} from "../../src/MockUSDC.sol";
import {ComplianceRegistry} from "../../src/ComplianceRegistry.sol";
import {TBillToken} from "../../src/TBillToken.sol";

contract AdjustableFeed is IPriceFeed {
    uint8 public override decimals;
    uint80 public roundId = 1;
    uint80 public answeredInRound = 1;
    uint256 public updatedAt;
    int256 public answer;
    constructor(uint8 dp, int256 initial) {
        decimals = dp;
        answer = initial;
        updatedAt = block.timestamp;
    }
    function setData(uint80 round, uint80 answered, int256 value, uint256 timestamp) external {
        roundId = round; answeredInRound = answered; answer = value; updatedAt = timestamp;
    }
    function latestRoundData() external view override returns (uint80,int256,uint256,uint256,uint80) {
        return (roundId, answer, updatedAt, updatedAt, answeredInRound);
    }
}

contract OptionalExtensionsTest is Test {
    function test_Tier3_FreshNav_Normalizes18DecimalsToEight() public {
        vm.warp(10 days);
        AdjustableFeed feed = new AdjustableFeed(18, 1_250_000_000_000_000_000);
        NavSafetyReader reader = new NavSafetyReader(feed, 1 days);
        assertEq(reader.freshNav8(), 125_000_000);
    }

    function test_Tier3_StaleNavRejected() public {
        vm.warp(10 days);
        AdjustableFeed feed = new AdjustableFeed(8, 1e8);
        NavSafetyReader reader = new NavSafetyReader(feed, 1 hours);
        vm.warp(block.timestamp + 1 hours + 1);
        vm.expectRevert(NavSafetyReader.StaleNav.selector);
        reader.freshNav8();
    }

    function test_Tier3_IncompleteRoundAndNonPositiveNavRejected() public {
        vm.warp(10 days);
        AdjustableFeed feed = new AdjustableFeed(8, 1e8);
        NavSafetyReader reader = new NavSafetyReader(feed, 1 hours);
        feed.setData(2, 1, 1e8, block.timestamp);
        vm.expectRevert(NavSafetyReader.IncompleteRound.selector);
        reader.freshNav8();
        feed.setData(2, 2, 0, block.timestamp);
        vm.expectRevert(NavSafetyReader.InvalidNav.selector);
        reader.freshNav8();
    }

    function test_Tier3_ChainlinkAdapter_PreservesRoundMetadata() public {
        vm.warp(10 days);
        AdjustableFeed feed = new AdjustableFeed(8, 123_456_789);
        feed.setData(7, 7, 123_456_789, block.timestamp);
        ChainlinkNavAdapter adapter = new ChainlinkNavAdapter(IAggregatorV3(address(feed)));
        assertEq(adapter.decimals(), 8);
        (uint80 rid, int256 answer,, uint256 updated, uint80 answered) = adapter.latestRoundData();
        assertEq(rid, 7);
        assertEq(answer, 123_456_789);
        assertEq(updated, block.timestamp);
        assertEq(answered, 7);
    }

    function test_Tier3_StalePriceActuallyBlocksSubscriptions() public {
        vm.warp(10 days);
        AdjustableFeed source = new AdjustableFeed(8, 1e8);
        NavSafetyReader reader = new NavSafetyReader(source, 1 hours);
        MockUSDC cash = new MockUSDC();
        ComplianceRegistry compliance = new ComplianceRegistry(address(this));
        TBillToken share = new TBillToken(address(this), compliance);
        GuardedSubscriptionVault sub = new GuardedSubscriptionVault(cash, share, reader);
        share.grantRole(share.MINTER_ROLE(), address(sub));
        address alice = makeAddr("subscribed-alice");
        compliance.setWhitelisted(alice, true);
        cash.faucet(alice, 200e6);
        vm.startPrank(alice);
        cash.approve(address(sub), 200e6);
        assertEq(sub.subscribe(100e6), 100e18);
        vm.stopPrank();
        assertEq(share.balanceOf(alice), 100e18);
        vm.warp(block.timestamp + 1 hours + 1);
        vm.expectRevert(NavSafetyReader.StaleNav.selector);
        vm.prank(alice);
        sub.subscribe(100e6);
    }

    function test_Tier3_RestrictedSecurityToken_ComplianceAndFreeze() public {
        address alice = makeAddr("alice");
        address bob = makeAddr("bob");
        RegulatedTransferPolicy registry = new RegulatedTransferPolicy(address(this));
        RegulatedTBillToken token = new RegulatedTBillToken(address(this), registry);
        registry.setVerified(alice, true);
        token.mint(alice, 100e18);
        vm.expectRevert(abi.encodeWithSelector(RegulatedTBillToken.IneligibleAccount.selector, bob));
        vm.prank(alice);
        token.transfer(bob, 1e18);
        registry.setVerified(bob, true);
        vm.prank(alice);
        token.transfer(bob, 1e18);
        assertEq(token.balanceOf(bob), 1e18);
        registry.setFrozen(alice, true);
        vm.expectRevert(abi.encodeWithSelector(RegulatedTBillToken.IneligibleAccount.selector, alice));
        vm.prank(alice);
        token.transfer(bob, 1e18);
    }
}
