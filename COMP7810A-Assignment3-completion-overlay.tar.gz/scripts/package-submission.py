#!/usr/bin/env python3
"""Package a *verified* COMP7810 A3 project; never include local wallet credentials.

This guards against accidental omission, not every possible secret pattern.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import re
import sys

root = Path(__file__).resolve().parents[1]
output = root / 'Assignment3-Yijia-Wang-final.zip'
excluded_dirs = {'.git', 'cache', 'out', 'broadcast', 'node_modules', '.venv', '__pycache__'}
excluded_names = {'.env', 'demo-state.json', '.DS_Store', 'START-HERE-中文.md', 'CODEX-TASK.md'}
required = [
    'README.md', 'EXERCISES.md', 'STUDENT-QUESTIONS.md', 'docs/architecture.svg',
    'docs/submission-checks.txt', 'src/exercises/RedemptionQueue.sol',
    'test/exercises/01_BridgeTasks.t.sol', 'test/exercises/02_QueueTasks.t.sol',
    'test/exercises/03_InvariantTasks.t.sol', 'test/challenges/FalseNav.t.sol',
]
for item in required:
    if not (root / item).is_file():
        sys.exit('Missing required project file: ' + item)

log = (root / 'docs/submission-checks.txt').read_text(errors='replace')
if 'RESULT: ALL CHECKS PASSED' not in log:
    sys.exit('Run all Foundry checks and save authentic results before packaging.')

readme = (root / 'README.md').read_text(encoding='utf-8')
if '## Deployment (Sepolia)' not in readme:
    sys.exit('README requires a ## Deployment (Sepolia) section.')

# Inspect the actual seven Markdown table rows, not narrative text explaining placeholders.
section = readme.split('## Deployment (Sepolia)', 1)[1]
contract_names = [
    'MockUSDC', 'ComplianceRegistry', 'MockPriceFeed', 'TBillToken',
    'MockTBillCustodian', 'TBillVault', 'RedemptionQueue'
]
addresses = []
for name in contract_names:
    match = re.search(r'^\|\s*' + re.escape(name) + r'\s*\|([^\n]*)$', section, re.M)
    if not match:
        sys.exit('No deployment-table row found for: ' + name)
    row = match.group(1)
    if 'NOT DEPLOYED' in row or 'NOT VERIFIED' in row:
        sys.exit('Complete the Sepolia table before packaging: ' + name)
    a = re.findall(r'0x[0-9a-fA-F]{40}', row)
    if not a:
        sys.exit('Missing 0x-prefixed 40-digit address for: ' + name)
    if not re.search(r'https://sepolia\.etherscan\.io/address/0x[0-9a-fA-F]{40}', row, re.I):
        sys.exit('Missing valid Etherscan address link for: ' + name)
    addresses.append(a[0].lower())
if len(set(addresses)) != len(contract_names):
    sys.exit('The seven Sepolia deployments must have seven distinct addresses.')

with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=6) as z:
    for f in sorted(root.rglob('*')):
        if not f.is_file():
            continue
        rel = f.relative_to(root)
        if any(part in excluded_dirs for part in rel.parts):
            continue
        if rel.name in excluded_names or rel.name.startswith('.env.') or rel.suffix.lower() in ('.key', '.pem'):
            continue
        if rel.suffix.lower() in ('.zip', '.tar', '.gz') or 'private-key' in rel.name.lower():
            continue
        z.write(f, rel.as_posix())

with ZipFile(output) as z:
    broken = z.testzip()
    if broken:
        sys.exit('ZIP CRC failed: ' + broken)
    contents = set(z.namelist())
    if not any(name.startswith('lib/') for name in contents):
        sys.exit('Missing required lib/ dependencies')
    if any('/.env' in name or name == '.env' for name in contents):
        sys.exit('Unexpected environment file in ZIP!')
print(f'Created: {output}\nFiles: {len(contents)}\nSize: {output.stat().st_size} bytes\nZIP integrity: OK')
print('Before Moodle: inspect secrets and verify every deployed contract on Etherscan.')
