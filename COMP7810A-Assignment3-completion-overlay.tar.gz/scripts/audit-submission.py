#!/usr/bin/env python3
"""Preflight: mandatory files, answer lengths, link count, suspicious key patterns.

This is a heuristic warning tool, not a guarantee that files contain no secret.
"""
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
fail=[]
required=[
    'src/exercises/RedemptionQueue.sol',
    'test/exercises/01_BridgeTasks.t.sol',
    'test/exercises/02_QueueTasks.t.sol',
    'test/exercises/03_InvariantTasks.t.sol',
    'test/challenges/FalseNav.t.sol',
    'STUDENT-QUESTIONS.md',
    'docs/architecture.svg',
    'README.md',
    'EXERCISES.md',
    'script/Deploy.s.sol',
]
for r in required:
    if not (root/r).is_file():fail.append('Missing '+r)
if not (root/'lib/forge-std').exists() or not (root/'lib/openzeppelin-contracts').exists():
    fail.append('Missing bundled libraries')
for x in root.rglob('.env'):
    if '.git' not in x.parts:
        print('Local .env exists (allowed locally; MUST NOT be packaged):',x.relative_to(root))
readme=(root/'README.md').read_text() if (root/'README.md').exists() else ''
if '## Deployment (Sepolia)' not in readme:fail.append('README missing exact Deployment heading')
table_rows = re.findall(r'(?m)^\|\s*(?:MockUSDC|ComplianceRegistry|MockPriceFeed|TBillToken|MockTBillCustodian|TBillVault|RedemptionQueue)\s*\|[^\n]+$',readme)
if len(table_rows) != 7 or any('NOT DEPLOYED YET' in row or 'NOT VERIFIED YET' in row for row in table_rows):
    fail.append('Deployment table still has placeholders or fewer than seven rows')
url_pattern=r'https://sepolia\.etherscan\.io/address/0x[0-9a-fA-F]{40}'
urls=set(re.findall(url_pattern,readme))
if len(urls)<7:fail.append(f'Need seven distinct Sepolia Etherscan links, found {len(urls)}')
qpath=root/'STUDENT-QUESTIONS.md'
if qpath.exists():
    s=qpath.read_text()
    for key in ['A1','A2','B1','B2','C1','C2','D1','D2']:
        m=re.search(r'(?m)^### '+key+r'\.[^\n]*\n([\s\S]*?)(?=\n### |\n## |\Z)',s)
        words=len(re.findall(r"\b[\w$-]+\b",m.group(1))) if m else 0
        print(key,'word count',words)
        if words<150 or words>300:fail.append(key+': outside 150–300 words')
pattern=re.compile(r'(?<![0-9a-fA-F])(?:0x)?[0-9a-fA-F]{64}(?![0-9a-fA-F])')
found=[]
for file in root.rglob('*'):
    if not file.is_file() or file.name == '.env' or any(x in {'.git','lib','cache','out','broadcast'} for x in file.parts):continue
    if file.suffix.lower() not in {'.sol','.md','.toml','.sh','.py','.txt','.json','.example',''}:continue
    if file.stat().st_size>2_000_000:continue
    for lineno,line in enumerate(file.read_text(errors='replace').splitlines(),1):
        if pattern.search(line):found.append((str(file.relative_to(root)),lineno))
if found:
    print('Potential 32-byte hex values in non-library text (manual review needed):',found[:30])
    fail.append('Inspect potential private key literals before submission')
print('Preflight:', 'PASS' if not fail else 'REQUIRES ATTENTION')
for e in fail:print(' -',e)
sys.exit(0 if not fail else 1)
