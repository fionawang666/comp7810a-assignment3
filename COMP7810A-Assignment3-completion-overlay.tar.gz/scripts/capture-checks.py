#!/usr/bin/env python3
"""Run authentic Foundry checks and save unedited stdout/stderr."""
from pathlib import Path
import subprocess, datetime, sys
root=Path(__file__).resolve().parents[1]
(root/'docs').mkdir(exist_ok=True)
commands=[
 ['make','doctor'],
 ['make','test'],
 ['make','exercise'],
 ['make','challenge'],
 ['forge','test','--match-path','test/tier3/*.t.sol'],
 ['forge','test'],
]
path=root/'docs'/'submission-checks.txt'
with path.open('w',encoding='utf-8') as log:
    header='COMP7810A A3 — authentic test evidence\n'+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n'
    log.write(header)
    print(header)
    errors=[]
    for args in commands:
        command=' '.join(args)
        msg='\n'+'='*72+'\n$ '+command+'\n'
        print(msg);log.write(msg);log.flush()
        try:
            p=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace')
            log.write(p.stdout); print(p.stdout[-2500:],end='')
            outcome=f'\n[{"PASS" if p.returncode==0 else "FAIL"}] {command}, exit={p.returncode}\n'
            if p.returncode:errors.append(command)
        except FileNotFoundError as e:
            outcome=f'\n[FAIL] {command}: {e}\n'
            errors.append(command)
        log.write(outcome);print(outcome);log.flush()
    result='RESULT: '+'ALL CHECKS PASSED' if not errors else 'RESULT: FAILED — '+', '.join(errors)
    log.write('\n'+result+'\n');print('\n'+result)
print('Saved:',path)
sys.exit(1 if errors else 0)
