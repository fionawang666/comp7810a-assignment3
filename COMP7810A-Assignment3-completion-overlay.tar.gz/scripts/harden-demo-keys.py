#!/usr/bin/env python3
"""Remove unqualified 32-byte Anvil private key literals from upstream homework files."""
from pathlib import Path
import re
make=Path('Makefile')
ex=Path('EXERCISES.md')
if not make.exists() or not ex.exists():raise SystemExit('Run in official project root')
s=make.read_text()
new,count1=re.subn(r'(?m)^(ANVIL_KEY\s*:?=)\s*0x[0-9a-fA-F]{64}\s*$',r'ANVIL_KEY ?=',s)
new,count2=re.subn(r'(?m)^(ATTACK_KEY\s*:?=)\s*0x[0-9a-fA-F]{64}\s*$',r'ATTACK_KEY ?=',new)
if count1 or count2:make.write_text(new)
s=ex.read_text()
s,n=re.subn(r'--private-key\s+0x[0-9a-fA-F]{64}',
            '--private-key "$ANVIL_KEY"',s)
if n:ex.write_text(s)
print('Makefile Anvil defaults removed:',count1+count2,'EXERCISES demo literal replaced:',n)
print('For local Anvil demos export ANVIL_KEY in the shell using account 0 from your live Anvil console.')
